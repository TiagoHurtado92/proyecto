from crear_tablas import crear_tablas
print("🚀 Ejecutando main.py y creando tablas si faltan...")
crear_tablas()

from vo.TerrenoVO import TerrenoVO
from dao.TerrenoDAO import TerrenoDAO

from vo.ArbolVO import ArbolVO
from dao.ArbolDAO import ArbolDAO

from vo.TrabajadorVO import TrabajadorVO
from dao.TrabajadorDAO import TrabajadorDAO

from vo.TareaVO import TareaVO
from dao.TareaDAO import TareaDAO

from vo.ProduccionVO import ProduccionVO
from dao.ProduccionDAO import ProduccionDAO

from vo.RecolectaVO import RecolectaVO
from dao.RecolectaDAO import RecolectaDAO

from vo.EnfermedadVO import EnfermedadVO
from dao.EnfermedadDAO import EnfermedadDAO

from vo.HistorialEnfermedadVO import HistorialEnfermedadVO
from dao.HistorialEnfermedadDAO import HistorialEnfermedadDAO

# 🚀 PRUEBAS DE INSERCIÓN Y LISTADO

# 1. Insertar Terreno
terreno = TerrenoVO(nombre="Terreno Principal", descripcion="Zona Norte")
TerrenoDAO().insertar(terreno)

# 2. Insertar Árbol
arbol = ArbolVO(codigo_arbol="ARB001", fecha_siembra="2025-01-01", id_terreno=1)
ArbolDAO().insertar(arbol)

# 3. Insertar Trabajador
trabajador = TrabajadorVO(documento_identidad="123456", nombre="Juan Pérez", telefono="3001234567", eps="SURA", arl="Colpatria")
TrabajadorDAO().insertar(trabajador)

# 4. Insertar Tarea
tarea = TareaVO(tipo="RECOLECCION", fecha="2025-02-01", mezcla="", peso_recolecta_kg=120.5, calidad="Alta", id_trabajador=1, id_arbol=1)
TareaDAO().insertar(tarea)

# 5. Insertar Producción
produccion = ProduccionVO(codigo_produccion="PROD001", fecha_conformacion="2025-02-02")
ProduccionDAO().insertar(produccion)

# 6. Insertar Recolecta
recolecta = RecolectaVO(id_produccion=1, id_tarea=1)
RecolectaDAO().insertar(recolecta)

# 7. Insertar Enfermedad
enfermedad = EnfermedadVO(nombre="Hongos", descripcion="Afecta las hojas", tratamiento="Fungicida", causa="Exceso de humedad")
EnfermedadDAO().insertar(enfermedad)

# 8. Insertar Historial de Enfermedad
historial = HistorialEnfermedadVO(id_arbol=1, id_enfermedad=1, fecha_deteccion="2025-02-05")
HistorialEnfermedadDAO().insertar(historial)

# 📋 LISTADOS
print("\n📋 LISTADO DE TERRENOS:")
for t in TerrenoDAO().listar():
    print(t.id_terreno, t.nombre, t.descripcion)

print("\n📋 LISTADO DE ÁRBOLES:")
for a in ArbolDAO().listar():
    print(a.id_arbol, a.codigo_arbol, a.fecha_siembra, a.id_terreno)

print("\n📋 LISTADO DE TRABAJADORES:")
for tr in TrabajadorDAO().listar():
    print(tr.id_trabajador, tr.documento_identidad, tr.nombre, tr.telefono, tr.eps, tr.arl)

print("\n📋 LISTADO DE TAREAS:")
for ta in TareaDAO().listar():
    print(ta.id_tarea, ta.tipo, ta.fecha, ta.peso_recolecta_kg, ta.calidad, ta.id_trabajador, ta.id_arbol)

print("\n📋 LISTADO DE PRODUCCIONES:")
for p in ProduccionDAO().listar():
    print(p.id_produccion, p.codigo_produccion, p.fecha_conformacion)

print("\n📋 LISTADO DE RECOLECTAS:")
for r in RecolectaDAO().listar():
    print(r.id_recolecta, r.id_produccion, r.id_tarea)

print("\n📋 LISTADO DE ENFERMEDADES:")
for e in EnfermedadDAO().listar():
    print(e.id_enfermedad, e.nombre, e.descripcion, e.tratamiento, e.causa)

print("\n📋 LISTADO DE HISTORIAL DE ENFERMEDADES:")
for h in HistorialEnfermedadDAO().listar():
    print(h.id_historial, h.id_arbol, h.id_enfermedad, h.fecha_deteccion)
