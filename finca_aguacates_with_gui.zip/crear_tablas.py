from db import get_connection

def crear_tablas():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS terreno (
        id_terreno INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT,
        descripcion TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS arbol (
        id_arbol INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo_arbol TEXT,
        fecha_siembra DATE,
        id_terreno INTEGER,
        FOREIGN KEY (id_terreno) REFERENCES terreno(id_terreno)
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS trabajador (
        id_trabajador INTEGER PRIMARY KEY AUTOINCREMENT,
        documento_identidad TEXT,
        nombre TEXT,
        telefono TEXT,
        eps TEXT,
        arl TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS tarea (
        id_tarea INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo TEXT CHECK(tipo IN ('NUTRICION','FUMIGACION','RECOLECCION')),
        fecha DATE,
        mezcla TEXT,
        peso_recolecta_kg DECIMAL(10,2),
        calidad TEXT,
        id_trabajador INTEGER,
        id_arbol INTEGER,
        FOREIGN KEY (id_trabajador) REFERENCES trabajador(id_trabajador),
        FOREIGN KEY (id_arbol) REFERENCES arbol(id_arbol)
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS produccion (
        id_produccion INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo_produccion TEXT,
        fecha_conformacion DATE
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS recolecta (
        id_recolecta INTEGER PRIMARY KEY AUTOINCREMENT,
        id_produccion INTEGER,
        id_tarea INTEGER,
        FOREIGN KEY (id_produccion) REFERENCES produccion(id_produccion),
        FOREIGN KEY (id_tarea) REFERENCES tarea(id_tarea)
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS enfermedad (
        id_enfermedad INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT,
        descripcion TEXT,
        tratamiento TEXT,
        causa TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS historial_enfermedad (
        id_historial INTEGER PRIMARY KEY AUTOINCREMENT,
        id_arbol INTEGER,
        id_enfermedad INTEGER,
        fecha_deteccion DATE,
        FOREIGN KEY (id_arbol) REFERENCES arbol(id_arbol),
        FOREIGN KEY (id_enfermedad) REFERENCES enfermedad(id_enfermedad)
    )
    """)

    conn.commit()
    conn.close()
    print("Tablas creadas correctamente.")

if __name__ == "__main__":
    crear_tablas()
    print("Tablas creadas correctamente")
