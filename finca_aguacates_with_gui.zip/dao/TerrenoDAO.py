from db import get_connection
from vo.TerrenoVO import TerrenoVO

class TerrenoDAO:
    def insertar(self, terreno: TerrenoVO):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO terreno (nombre, descripcion) VALUES (?, ?)", 
                       (terreno.nombre, terreno.descripcion))
        conn.commit()
        conn.close()

    def listar(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id_terreno, nombre, descripcion FROM terreno")
        rows = cursor.fetchall()
        conn.close()
        return [TerrenoVO(id_terreno=row[0], nombre=row[1], descripcion=row[2]) for row in rows]
