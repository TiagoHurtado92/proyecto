from db import get_connection
from vo.TareaVO import TareaVO

class TareaDAO:
    def insertar(self, tarea: TareaVO):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""INSERT INTO tarea (tipo, fecha, mezcla, peso_recolecta_kg, calidad, id_trabajador, id_arbol) 
                          VALUES (?, ?, ?, ?, ?, ?, ?)""",
                       (tarea.tipo, tarea.fecha, tarea.mezcla, tarea.peso_recolecta_kg, tarea.calidad, tarea.id_trabajador, tarea.id_arbol))
        conn.commit()
        conn.close()

    def listar(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id_tarea, tipo, fecha, mezcla, peso_recolecta_kg, calidad, id_trabajador, id_arbol FROM tarea")
        rows = cursor.fetchall()
        conn.close()
        return [TareaVO(id_tarea=row[0], tipo=row[1], fecha=row[2], mezcla=row[3], peso_recolecta_kg=row[4], calidad=row[5], id_trabajador=row[6], id_arbol=row[7]) for row in rows]
