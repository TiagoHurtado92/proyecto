from db import get_connection
from vo.HistorialEnfermedadVO import HistorialEnfermedadVO

class HistorialEnfermedadDAO:
    def insertar(self, historial: HistorialEnfermedadVO):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO historial_enfermedad (id_arbol, id_enfermedad, fecha_deteccion) VALUES (?, ?, ?)",
                       (historial.id_arbol, historial.id_enfermedad, historial.fecha_deteccion))
        conn.commit()
        conn.close()

    def listar(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id_historial, id_arbol, id_enfermedad, fecha_deteccion FROM historial_enfermedad")
        rows = cursor.fetchall()
        conn.close()
        return [HistorialEnfermedadVO(id_historial=row[0], id_arbol=row[1], id_enfermedad=row[2], fecha_deteccion=row[3]) for row in rows]
