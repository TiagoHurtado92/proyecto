from db import get_connection
from vo.EnfermedadVO import EnfermedadVO

class EnfermedadDAO:
    def insertar(self, enfermedad: EnfermedadVO):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO enfermedad (nombre, descripcion, tratamiento, causa) VALUES (?, ?, ?, ?)",
                       (enfermedad.nombre, enfermedad.descripcion, enfermedad.tratamiento, enfermedad.causa))
        conn.commit()
        conn.close()

    def listar(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id_enfermedad, nombre, descripcion, tratamiento, causa FROM enfermedad")
        rows = cursor.fetchall()
        conn.close()
        return [EnfermedadVO(id_enfermedad=row[0], nombre=row[1], descripcion=row[2], tratamiento=row[3], causa=row[4]) for row in rows]
