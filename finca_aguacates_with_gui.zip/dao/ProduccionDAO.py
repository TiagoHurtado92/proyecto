from db import get_connection
from vo.ProduccionVO import ProduccionVO

class ProduccionDAO:
    def insertar(self, produccion: ProduccionVO):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO produccion (codigo_produccion, fecha_conformacion) VALUES (?, ?)",
                       (produccion.codigo_produccion, produccion.fecha_conformacion))
        conn.commit()
        conn.close()

    def listar(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id_produccion, codigo_produccion, fecha_conformacion FROM produccion")
        rows = cursor.fetchall()
        conn.close()
        return [ProduccionVO(id_produccion=row[0], codigo_produccion=row[1], fecha_conformacion=row[2]) for row in rows]
