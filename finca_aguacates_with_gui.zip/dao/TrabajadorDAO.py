from db import get_connection
from vo.TrabajadorVO import TrabajadorVO

class TrabajadorDAO:
    def insertar(self, trabajador: TrabajadorVO):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO trabajador (documento_identidad, nombre, telefono, eps, arl) VALUES (?, ?, ?, ?, ?)",
                       (trabajador.documento_identidad, trabajador.nombre, trabajador.telefono, trabajador.eps, trabajador.arl))
        conn.commit()
        conn.close()

    def listar(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id_trabajador, documento_identidad, nombre, telefono, eps, arl FROM trabajador")
        rows = cursor.fetchall()
        conn.close()
        return [TrabajadorVO(id_trabajador=row[0], documento_identidad=row[1], nombre=row[2], telefono=row[3], eps=row[4], arl=row[5]) for row in rows]
