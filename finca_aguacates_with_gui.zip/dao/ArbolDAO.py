from db import get_connection
from vo.ArbolVO import ArbolVO

class ArbolDAO:
    def insertar(self, arbol: ArbolVO):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO arbol (codigo_arbol, fecha_siembra, id_terreno) VALUES (?, ?, ?)",
                       (arbol.codigo_arbol, arbol.fecha_siembra, arbol.id_terreno))
        conn.commit()
        conn.close()

    def listar(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id_arbol, codigo_arbol, fecha_siembra, id_terreno FROM arbol")
        rows = cursor.fetchall()
        conn.close()
        return [ArbolVO(id_arbol=row[0], codigo_arbol=row[1], fecha_siembra=row[2], id_terreno=row[3]) for row in rows]
