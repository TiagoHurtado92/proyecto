from db import get_connection
from vo.RecolectaVO import RecolectaVO

class RecolectaDAO:
    def insertar(self, recolecta: RecolectaVO):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO recolecta (id_produccion, id_tarea) VALUES (?, ?)",
                       (recolecta.id_produccion, recolecta.id_tarea))
        conn.commit()
        conn.close()

    def listar(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id_recolecta, id_produccion, id_tarea FROM recolecta")
        rows = cursor.fetchall()
        conn.close()
        return [RecolectaVO(id_recolecta=row[0], id_produccion=row[1], id_tarea=row[2]) for row in rows]
