class ArbolVO:
    def __init__(self, id_arbol=None, codigo_arbol="", fecha_siembra=None, id_terreno=None):
        self.id_arbol = id_arbol
        self.codigo_arbol = codigo_arbol
        self.fecha_siembra = fecha_siembra
        self.id_terreno = id_terreno
