class TrabajadorVO:
    def __init__(self, id_trabajador=None, documento_identidad="", nombre="", telefono="", eps="", arl=""):
        self.id_trabajador = id_trabajador
        self.documento_identidad = documento_identidad
        self.nombre = nombre
        self.telefono = telefono
        self.eps = eps
        self.arl = arl
