class ProduccionVO:
    def __init__(self, id_produccion=None, codigo_produccion="", fecha_conformacion=None):
        self.id_produccion = id_produccion
        self.codigo_produccion = codigo_produccion
        self.fecha_conformacion = fecha_conformacion
