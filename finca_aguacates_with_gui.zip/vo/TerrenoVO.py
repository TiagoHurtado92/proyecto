class TerrenoVO:
    def __init__(self, id_terreno=None, nombre="", descripcion=""):
        self.id_terreno = id_terreno
        self.nombre = nombre
        self.descripcion = descripcion
