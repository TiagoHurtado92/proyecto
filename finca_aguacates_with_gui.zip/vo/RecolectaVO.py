class RecolectaVO:
    def __init__(self, id_recolecta=None, id_produccion=None, id_tarea=None):
        self.id_recolecta = id_recolecta
        self.id_produccion = id_produccion
        self.id_tarea = id_tarea
