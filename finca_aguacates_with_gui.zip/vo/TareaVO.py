class TareaVO:
    def __init__(self, id_tarea=None, tipo="", fecha=None, mezcla="", peso_recolecta_kg=0.0, calidad="", id_trabajador=None, id_arbol=None):
        self.id_tarea = id_tarea
        self.tipo = tipo
        self.fecha = fecha
        self.mezcla = mezcla
        self.peso_recolecta_kg = peso_recolecta_kg
        self.calidad = calidad
        self.id_trabajador = id_trabajador
        self.id_arbol = id_arbol
