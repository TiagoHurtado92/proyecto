class EnfermedadVO:
    def __init__(self, id_enfermedad=None, nombre="", descripcion="", tratamiento="", causa=""):
        self.id_enfermedad = id_enfermedad
        self.nombre = nombre
        self.descripcion = descripcion
        self.tratamiento = tratamiento
        self.causa = causa
