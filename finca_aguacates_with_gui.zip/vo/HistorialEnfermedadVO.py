class HistorialEnfermedadVO:
    def __init__(self, id_historial=None, id_arbol=None, id_enfermedad=None, fecha_deteccion=None):
        self.id_historial = id_historial
        self.id_arbol = id_arbol
        self.id_enfermedad = id_enfermedad
        self.fecha_deteccion = fecha_deteccion
