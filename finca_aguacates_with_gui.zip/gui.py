import tkinter as tk
from tkinter import ttk, messagebox
from dao.TerrenoDAO import TerrenoDAO
from dao.ArbolDAO import ArbolDAO
from dao.TrabajadorDAO import TrabajadorDAO
from dao.TareaDAO import TareaDAO
from dao.ProduccionDAO import ProduccionDAO
from dao.RecolectaDAO import RecolectaDAO
from dao.EnfermedadDAO import EnfermedadDAO
from dao.HistorialEnfermedadDAO import HistorialEnfermedadDAO

from vo.TerrenoVO import TerrenoVO
from vo.ArbolVO import ArbolVO
from vo.TrabajadorVO import TrabajadorVO
from vo.TareaVO import TareaVO
from vo.ProduccionVO import ProduccionVO
from vo.RecolectaVO import RecolectaVO
from vo.EnfermedadVO import EnfermedadVO
from vo.HistorialEnfermedadVO import HistorialEnfermedadVO

class BaseFrame(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=10)

class TerrenoFrame(BaseFrame):
    def __init__(self, parent):
        super().__init__(parent)
        ttk.Label(self, text="Nombre").grid(row=0, column=0, sticky="w")
        self.nombre = ttk.Entry(self); self.nombre.grid(row=0, column=1)
        ttk.Label(self, text="Descripción").grid(row=1, column=0, sticky="w")
        self.descripcion = ttk.Entry(self); self.descripcion.grid(row=1, column=1)
        ttk.Button(self, text="Guardar", command=self.guardar).grid(row=2, column=0, pady=5)
        ttk.Button(self, text="Listar", command=self.listar).grid(row=2, column=1, pady=5)
        self.text = tk.Text(self, height=10, width=60); self.text.grid(row=3, column=0, columnspan=2, pady=5)

    def guardar(self):
        nombre = self.nombre.get().strip()
        desc = self.descripcion.get().strip()
        if not nombre:
            messagebox.showerror("Error", "Nombre obligatorio")
            return
        TerrenoDAO().insertar(TerrenoVO(nombre=nombre, descripcion=desc))
        messagebox.showinfo("Éxito", "Terreno guardado")

    def listar(self):
        self.text.delete("1.0", tk.END)
        for t in TerrenoDAO().listar():
            self.text.insert(tk.END, f"{t.id_terreno} | {t.nombre} | {t.descripcion}\n")

class ArbolFrame(BaseFrame):
    def __init__(self, parent):
        super().__init__(parent)
        ttk.Label(self, text="Código").grid(row=0, column=0, sticky="w")
        self.codigo = ttk.Entry(self); self.codigo.grid(row=0, column=1)
        ttk.Label(self, text="Fecha Siembra (YYYY-MM-DD)").grid(row=1, column=0, sticky="w")
        self.fecha = ttk.Entry(self); self.fecha.grid(row=1, column=1)
        ttk.Label(self, text="ID Terreno").grid(row=2, column=0, sticky="w")
        self.id_terreno = ttk.Entry(self); self.id_terreno.grid(row=2, column=1)
        ttk.Button(self, text="Guardar", command=self.guardar).grid(row=3, column=0, pady=5)
        ttk.Button(self, text="Listar", command=self.listar).grid(row=3, column=1, pady=5)
        self.text = tk.Text(self, height=10, width=80); self.text.grid(row=4, column=0, columnspan=2, pady=5)

    def guardar(self):
        codigo = self.codigo.get().strip()
        fecha = self.fecha.get().strip()
        idt = self.id_terreno.get().strip() or None
        try:
            idt = int(idt) if idt is not None else None
        except:
            messagebox.showerror("Error", "ID Terreno debe ser entero")
            return
        ArbolDAO().insertar(ArbolVO(codigo_arbol=codigo, fecha_siembra=fecha, id_terreno=idt))
        messagebox.showinfo("Éxito", "Árbol guardado")

    def listar(self):
        self.text.delete("1.0", tk.END)
        for a in ArbolDAO().listar():
            self.text.insert(tk.END, f"{a.id_arbol} | {a.codigo_arbol} | {a.fecha_siembra} | terreno:{a.id_terreno}\n")

class TrabajadorFrame(BaseFrame):
    def __init__(self, parent):
        super().__init__(parent)
        labels = ["Documento", "Nombre", "Teléfono", "EPS", "ARL"]
        self.entries = {}
        for i,l in enumerate(labels):
            ttk.Label(self, text=l).grid(row=i, column=0, sticky="w")
            e = ttk.Entry(self); e.grid(row=i, column=1)
            self.entries[l] = e
        ttk.Button(self, text="Guardar", command=self.guardar).grid(row=5, column=0, pady=5)
        ttk.Button(self, text="Listar", command=self.listar).grid(row=5, column=1, pady=5)
        self.text = tk.Text(self, height=10, width=80); self.text.grid(row=6, column=0, columnspan=2, pady=5)

    def guardar(self):
        doc = self.entries["Documento"].get().strip()
        nombre = self.entries["Nombre"].get().strip()
        tel = self.entries["Teléfono"].get().strip()
        eps = self.entries["EPS"].get().strip()
        arl = self.entries["ARL"].get().strip()
        if not doc or not nombre:
            messagebox.showerror("Error", "Documento y Nombre obligatorios")
            return
        TrabajadorDAO().insertar(TrabajadorVO(documento_identidad=doc, nombre=nombre, telefono=tel, eps=eps, arl=arl))
        messagebox.showinfo("Éxito", "Trabajador guardado")

    def listar(self):
        self.text.delete("1.0", tk.END)
        for tr in TrabajadorDAO().listar():
            self.text.insert(tk.END, f"{tr.id_trabajador} | {tr.documento_identidad} | {tr.nombre} | {tr.telefono} | {tr.eps} | {tr.arl}\n")

class TareaFrame(BaseFrame):
    def __init__(self, parent):
        super().__init__(parent)
        labels = ["Tipo (NUTRICION/FUMIGACION/RECOLECCION)", "Fecha (YYYY-MM-DD)", "Mezcla", "Peso recolecta (kg)", "Calidad", "ID Trabajador", "ID Árbol"]
        self.entries = {}
        for i,l in enumerate(labels):
            ttk.Label(self, text=l).grid(row=i, column=0, sticky="w")
            e = ttk.Entry(self); e.grid(row=i, column=1)
            self.entries[l] = e
        ttk.Button(self, text="Guardar", command=self.guardar).grid(row=len(labels), column=0, pady=5)
        ttk.Button(self, text="Listar", command=self.listar).grid(row=len(labels), column=1, pady=5)
        self.text = tk.Text(self, height=10, width=120); self.text.grid(row=len(labels)+1, column=0, columnspan=2, pady=5)

    def guardar(self):
        tipo = self.entries["Tipo (NUTRICION/FUMIGACION/RECOLECCION)"].get().strip()
        fecha = self.entries["Fecha (YYYY-MM-DD)"].get().strip()
        mezcla = self.entries["Mezcla"].get().strip()
        peso = self.entries["Peso recolecta (kg)"].get().strip() or 0.0
        calidad = self.entries["Calidad"].get().strip()
        id_tr = self.entries["ID Trabajador"].get().strip() or None
        id_ar = self.entries["ID Árbol"].get().strip() or None
        try:
            peso = float(peso)
            id_tr = int(id_tr) if id_tr else None
            id_ar = int(id_ar) if id_ar else None
        except:
            messagebox.showerror("Error", "Tipo de dato incorrecto")
            return
        TareaDAO().insertar(TareaVO(tipo=tipo, fecha=fecha, mezcla=mezcla, peso_recolecta_kg=peso, calidad=calidad, id_trabajador=id_tr, id_arbol=id_ar))
        messagebox.showinfo("Éxito", "Tarea guardada")

    def listar(self):
        self.text.delete("1.0", tk.END)
        for ta in TareaDAO().listar():
            self.text.insert(tk.END, f"{ta.id_tarea} | {ta.tipo} | {ta.fecha} | {ta.mezcla} | {ta.peso_recolecta_kg} | {ta.calidad} | trab:{ta.id_trabajador} | arbol:{ta.id_arbol}\n")

class ProduccionFrame(BaseFrame):
    def __init__(self, parent):
        super().__init__(parent)
        ttk.Label(self, text="Código Producción").grid(row=0, column=0, sticky="w")
        self.codigo = ttk.Entry(self); self.codigo.grid(row=0, column=1)
        ttk.Label(self, text="Fecha conformación (YYYY-MM-DD)").grid(row=1, column=0, sticky="w")
        self.fecha = ttk.Entry(self); self.fecha.grid(row=1, column=1)
        ttk.Button(self, text="Guardar", command=self.guardar).grid(row=2, column=0)
        ttk.Button(self, text="Listar", command=self.listar).grid(row=2, column=1)
        self.text = tk.Text(self, height=10, width=80); self.text.grid(row=3, column=0, columnspan=2)

    def guardar(self):
        ProduccionDAO().insertar(ProduccionVO(codigo_produccion=self.codigo.get().strip(), fecha_conformacion=self.fecha.get().strip()))
        messagebox.showinfo("Éxito", "Producción guardada")

    def listar(self):
        self.text.delete("1.0", tk.END)
        for p in ProduccionDAO().listar():
            self.text.insert(tk.END, f"{p.id_produccion} | {p.codigo_produccion} | {p.fecha_conformacion}\n")

class RecolectaFrame(BaseFrame):
    def __init__(self, parent):
        super().__init__(parent)
        ttk.Label(self, text="ID Producción").grid(row=0, column=0, sticky="w")
        self.id_prod = ttk.Entry(self); self.id_prod.grid(row=0, column=1)
        ttk.Label(self, text="ID Tarea").grid(row=1, column=0, sticky="w")
        self.id_tarea = ttk.Entry(self); self.id_tarea.grid(row=1, column=1)
        ttk.Button(self, text="Guardar", command=self.guardar).grid(row=2, column=0)
        ttk.Button(self, text="Listar", command=self.listar).grid(row=2, column=1)
        self.text = tk.Text(self, height=10, width=60); self.text.grid(row=3, column=0, columnspan=2)

    def guardar(self):
        try:
            idp = int(self.id_prod.get().strip())
            idt = int(self.id_tarea.get().strip())
        except:
            messagebox.showerror("Error", "IDs deben ser enteros")
            return
        RecolectaDAO().insertar(RecolectaVO(id_produccion=idp, id_tarea=idt))
        messagebox.showinfo("Éxito", "Recolecta guardada")

    def listar(self):
        self.text.delete("1.0", tk.END)
        for r in RecolectaDAO().listar():
            self.text.insert(tk.END, f"{r.id_recolecta} | prod:{r.id_produccion} | tarea:{r.id_tarea}\n")

class EnfermedadFrame(BaseFrame):
    def __init__(self, parent):
        super().__init__(parent)
        labels = ["Nombre", "Descripción", "Tratamiento", "Causa"]
        self.entries = {}
        for i,l in enumerate(labels):
            ttk.Label(self, text=l).grid(row=i, column=0, sticky="w")
            e = ttk.Entry(self); e.grid(row=i, column=1)
            self.entries[l] = e
        ttk.Button(self, text="Guardar", command=self.guardar).grid(row=4, column=0)
        ttk.Button(self, text="Listar", command=self.listar).grid(row=4, column=1)
        self.text = tk.Text(self, height=10, width=80); self.text.grid(row=5, column=0, columnspan=2)

    def guardar(self):
        EnfermedadDAO().insertar(EnfermedadVO(nombre=self.entries["Nombre"].get().strip(),
                                              descripcion=self.entries["Descripción"].get().strip(),
                                              tratamiento=self.entries["Tratamiento"].get().strip(),
                                              causa=self.entries["Causa"].get().strip()))
        messagebox.showinfo("Éxito", "Enfermedad guardada")

    def listar(self):
        self.text.delete("1.0", tk.END)
        for e in EnfermedadDAO().listar():
            self.text.insert(tk.END, f"{e.id_enfermedad} | {e.nombre} | {e.descripcion} | {e.tratamiento} | {e.causa}\n")

class HistorialFrame(BaseFrame):
    def __init__(self, parent):
        super().__init__(parent)
        ttk.Label(self, text="ID Árbol").grid(row=0, column=0, sticky="w")
        self.id_arbol = ttk.Entry(self); self.id_arbol.grid(row=0, column=1)
        ttk.Label(self, text="ID Enfermedad").grid(row=1, column=0, sticky="w")
        self.id_enf = ttk.Entry(self); self.id_enf.grid(row=1, column=1)
        ttk.Label(self, text="Fecha detección (YYYY-MM-DD)").grid(row=2, column=0, sticky="w")
        self.fecha = ttk.Entry(self); self.fecha.grid(row=2, column=1)
        ttk.Button(self, text="Guardar", command=self.guardar).grid(row=3, column=0)
        ttk.Button(self, text="Listar", command=self.listar).grid(row=3, column=1)
        self.text = tk.Text(self, height=10, width=80); self.text.grid(row=4, column=0, columnspan=2)

    def guardar(self):
        try:
            ida = int(self.id_arbol.get().strip())
            ide = int(self.id_enf.get().strip())
        except:
            messagebox.showerror("Error", "IDs deben ser enteros")
            return
        HistorialEnfermedadDAO().insertar(HistorialEnfermedadVO(id_arbol=ida, id_enfermedad=ide, fecha_deteccion=self.fecha.get().strip()))
        messagebox.showinfo("Éxito", "Historial guardado")

    def listar(self):
        self.text.delete("1.0", tk.END)
        for h in HistorialEnfermedadDAO().listar():
            self.text.insert(tk.END, f"{h.id_historial} | arbol:{h.id_arbol} | enf:{h.id_enfermedad} | {h.fecha_deteccion}\n")

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Finca Aguacates - Gestión")
        self.geometry("900x600")
        nb = ttk.Notebook(self)
        frames = [
            ("Terrenos", TerrenoFrame(nb)),
            ("Árboles", ArbolFrame(nb)),
            ("Trabajadores", TrabajadorFrame(nb)),
            ("Tareas", TareaFrame(nb)),
            ("Producciones", ProduccionFrame(nb)),
            ("Recolectas", RecolectaFrame(nb)),
            ("Enfermedades", EnfermedadFrame(nb)),
            ("Historial", HistorialFrame(nb))
        ]
        for name, frame in frames:
            nb.add(frame, text=name)
        nb.pack(expand=1, fill="both")

if __name__ == "__main__":
    # Ensure DB tables exist by calling crear_tablas if available
    try:
        from crear_tablas import crear_tablas
        crear_tablas()
    except Exception:
        pass
    app = App()
    app.mainloop()
