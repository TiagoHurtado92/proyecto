# Finca Aguacates (Python + SQLite)

## Cómo ejecutar
1) Abre una terminal en esta carpeta (`finca_aguacates`).
2) Ejecuta:
   python3 main.py

El `main.py` ahora llama automáticamente a `crear_tablas.py` (no necesitas correrlo aparte). 
Verás en consola los datos de prueba insertados y listados.

## Estructura
- db.py: conexión SQLite
- crear_tablas.py: crea todas las tablas
- main.py: script de prueba que crea tablas, inserta datos y lista
- vo/: Value Objects
- dao/: Data Access Objects

> Nota: no incluí el directorio `venv/` para que el zip sea liviano. Si quieres usar entorno virtual:
   python3 -m venv venv
   source venv/bin/activate  (Mac/Linux)
   venv\Scripts\activate   (Windows)
y luego ejecuta `python3 main.py`.
